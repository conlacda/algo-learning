#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

// Copy from nealwu's template - http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2016/p0200r0.html
template<class Fun> class y_combinator_result { Fun fun_; public:template<class T> explicit y_combinator_result(T &&fun): fun_(std::forward<T>(fun)) {} template<class ...Args> decltype(auto) operator()(Args &&...args) { return fun_(std::ref(*this), std::forward<Args>(args)...); }}; template<class Fun> decltype(auto) y_combinator(Fun &&fun) { return y_combinator_result<std::decay_t<Fun>>(std::forward<Fun>(fun)); }

#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#endif

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    // cout << setprecision(2);
    int n;
    cin >> n;

    
    cerr << "Time : " << (double)clock() / (double)CLOCKS_PER_SEC << "s\n";
}
https://cses.fi/problemset/task/2110
Với 1 string có độ dài 2 thì sẽ có O(N) string trải dài từ đầu tới cuối cụ thể là s.size() +1 - 2
Query trên LCP tìm xem có bao nhiêu số lớn hơn 2 thì trừ đi bằng đó số.
LCP thể hiện độ dài chung 2 substr. Với lcp > 2 nghĩa là substr đó đang xuất hiện 2 lần.
-> trừ đi số lượng trùng là đc
Segmentree query số lượng số lớn hơn K có trong dãy