class Random {
  public:
    Random(){
        srand (time(NULL));
        // this->generate();
    }

    ll Int(ll l, ll r){
        r++; if (l==r) return l;
        assert(l<r);
        return rand() %(r-l)+l; // assert(21<= r.randRange(21, 100) && r.randRange(21, 100) <= 100);
    }

    vector<ll> Arr(ll l, ll r, int num, bool unique = false){
        if (unique) assert(r-l+1 >= num);
        map<ll, bool> m;
        vector<ll> ans;
        for (int i=0;i<num;i++){
            ll k = this->Int(l, r);
            if (unique)
                while (m.find(k) != m.end())
                    k = this->Int(l, r);
            ans.push_back(this->Int(l, r));
        }
        return ans;
    }
    // char Char(string str = "abcdefghijklmnopqrstuvwxyz"){
    //     ll idx = this->Int(0, str.size()-1);
    //     return str[idx];
    // }
    char Char(int min_char=33, int max_char=126){ // dùng max của char -> char(int_code)
       return char(this->Int(min_char, max_char)); 
    }
    string Str(int size){ // min_size
        string result = "";
        for (int i=0;i<size;i++){
            result += this->Char();
        }
        return result;
    }
    string Str(int min_size, int max_size){
        ll size = this->Int(min_size, max_size);
        return this->Str(size);
    }
    vector<vector<ll>> Graph(){
        // TODO
        vector<vector<ll>> result;
        return result;
    }
    vector<vector<ll>> Tree(){
        // TODO 
        // Phần này dùng DSU để chắc chắn nó không có cycle
        vector<vector<ll>> result;
        return result;
    }
    // TODO char, string, ...
    void generate();
};
Random random;
/*
Random r;
r.Int(0, 10); [0, 10]
r.Arr(l, r, num, [unique]); // random 1 vector co chua num so tu [l, r] va co unique khong
r.Char(); // trả về 1 ký tự
r.Str(10); // trả về 1 string với size = 10
r.Str(2, 4); // trả về String có size từ 2->4
*/
void Random::generate(){
    std::ofstream cout("inp.txt");
    cout << Int(0, 10);
    cout.close();
}