// Fast Suffix Array
#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

// Copy from nealwu's template - http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2016/p0200r0.html
template<class Fun> class y_combinator_result { Fun fun_; public:template<class T> explicit y_combinator_result(T &&fun): fun_(std::forward<T>(fun)) {} template<class ...Args> decltype(auto) operator()(Args &&...args) { return fun_(std::ref(*this), std::forward<Args>(args)...); }}; template<class Fun> decltype(auto) y_combinator(Fun &&fun) { return y_combinator_result<std::decay_t<Fun>>(std::forward<Fun>(fun)); }

#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#endif

// Verification: https://codeforces.com/contest/271/submission/169504228 - chạy C++20 > C++17 64 > C++17 32bit
class Hash {
private:
    vector<ll> pc;
    ll factor = 31;
    ll length;
    vector<ll> inv;
    string s;
public:
    Hash(){}
    void build(ll length = 200005){
        // Pre compute 
        ll p = 1;
        for (ll i=0;i<length;i++){
            pc.push_back(p);
            p = (p* factor) % mod;
        }
        for (auto v: pc) inv.push_back(mod_inv(v));
    }
    ll once(string s){
        // Hash 1 lần và không lưu thông tin gì khác. return hash_value nếu ko cần dùng mask 
        ll hash_value = 0;
        for (int i=0;i<(int)s.size();i++){
            int v = s[i] - 'a' + 1;
            hash_value = (hash_value + 1LL*v*pc[i]) % mod;
        }
        dbg(hash_value); // hash ko có mask
        return stoll(to_string(s[0] - 'a' +1) + to_string(s[s.size()-1] - 'a' + 1) + to_string(s.size()) + to_string(hash_value));
    }
    // a*x ≡ 1 mod m -> find x
    // a nhỏ hơn thì tính nhanh hơn. ví dụ k*mod_inv(i) nhanh hơn mod_inv(k*i)
    ll mod_inv(ll a) {
        ll x, y;
        auto extended_gcd = [&] (ll a, ll b) -> ll {
            x = 1; y =0;
            ll x1 = 0, y1 = 1, a1 = a, b1 = b;
            while (b1) {
                ll q = a1 / b1;
                tie(x, x1) = make_tuple(x1, x - q * x1);
                tie(y, y1) = make_tuple(y1, y - q * y1);
                tie(a1, b1) = make_tuple(b1, a1 - q * b1);
            }
            return a1; // a1 chính là std::gcd(a, b);
        };
        ll g = extended_gcd(a, mod);
        if (g != 1) return -1;
        else x = (x%mod +mod) %mod;
        return x;
    }

    vector<ll> prefix_hash;
    void load(string s){
        this->s = s;
        // Precompute để lần sau tính hash value của mọi substring của s
        prefix_hash.resize(0);
        ll hash_value = 0;
        for (int i=0;i<=(int)s.size();i++){
            int v = s[i] - 'a' + 1;
            hash_value = (hash_value + 1LL*v*pc[i]) %mod;
            prefix_hash.push_back(hash_value);
        }
    }
    // Hash string và gắn mask vào kết quả sau string. hash_with_mask = length + s[l] + s[r] + hash_value(s[l:r]) -> long long. Nếu chỉ có hash_value(s[l:r]) thì tỉ lệ collison ~ 1 vì string 1k kí tự -> có 1tr substr -> so 1tr string đôi 1 trong không gian mẫu mod (1 tỷ) thì tỷ lệ collision ~ 1 (bài toán sinh nhật - 40 người tỉ lệ collision ngày sinh là 70%)
    ll substr(ll l, ll r){
        // assert(0<=l && l <= r && r <= prefix_hash.size());
        assert(0<=l);
        assert(l<=r);
        if (r > prefix_hash.size()) {
            dbg(r, prefix_hash.size());
        }
        assert(r<=prefix_hash.size());
        string mask = "";
        mask += to_string(r-l+1);
        mask += to_string(s[l] - 'a' + 1);
        mask += to_string(s[r] - 'a' + 1);
        if (l == 0) return stoll(mask + to_string(prefix_hash[r]));
        ll ans = (prefix_hash[r] - prefix_hash[l-1] + mod) % mod;
        return stoll(mask + to_string((ans * inv[l]) % mod));
    }
    // So sánh 2 substring của s
    ll compare_2substrs(ll st1, ll len1, ll st2, ll len2){ // s.substr(st1, len1) <=> s.substr(st1, len2)
        ll size = min(len1, len2);
        ll left = 0, right = size;
        while (left < right - 1){
            ll mid = (left + right) /2;
            if (substr(st1, st1 + mid) != substr(st2, st2 + mid)){
                right = mid-1;
            } else left = mid;
        }
        while (left < size && s[st1 + left] == s[st2 + left]) left++;
        if (left == size) {
            if (len1 > len2) return 1;
            else if (len1 < len2) return -1;
            else return 0;
        }
        if (s[st1 + left] > s[st2 + left]) return 1;
        else if (s[st1 + left] < s[st2 + left]) return -1;
        return 0;
    }
};
/*
Hash hash();
hash.build(); // hash.build(s.size() + 5); mặc định độ dài string tới 2*1e5 
hash.once(str); trả ra giá trị hash của str 
// Khi muốn tính hash của mọi substring của s
hash.load(s); // O(n)
hash.substr(l, r); // = hash.once(s[l, r]); bao gồm l, r O(1) cho mỗi query
hash.compare_2substrs(index1, len1, index2, len2); // a>b -> 1. a<b -> -1. a==b -> 0
*/
Hash g_hash;
// Copy from: https://cp-algorithms.com/string/suffix-array.html
struct SuffixArray{
    string s; int n;
    vector<int> suffix_array, lcp;
    Hash hash, subhash;
    SuffixArray(string s){
        this->s = s; n = s.size();
        suffix_array = cal_suffix_array(s + '$');
        lcp = cal_lcp();
    }
    void add_hash(Hash hashed){
        this->hash = hashed;
        this->hash.load(s);
        this->subhash = hashed;
    }
    vector<int> cal_suffix_array(string s){
        int n = s.size();
        const int alphabet = 256;

        vector<int> p(n), c(n), cnt(max(alphabet, n), 0);
        for (int i = 0; i < n; i++) cnt[s[i]]++;
        for (int i = 1; i < alphabet; i++) cnt[i] += cnt[i-1];
        for (int i = 0; i < n; i++) p[--cnt[s[i]]] = i;
        c[p[0]] = 0;
        int classes = 1;
        for (int i = 1; i < n; i++) {
            if (s[p[i]] != s[p[i-1]]) classes++;
            c[p[i]] = classes - 1;
        }
        vector<int> pn(n), cn(n);
        for (int h = 0; (1 << h) < n; ++h) {
            for (int i = 0; i < n; i++) {
                pn[i] = p[i] - (1 << h);
                if (pn[i] < 0) pn[i] += n;
            }
            fill(cnt.begin(), cnt.begin() + classes, 0);
            for (int i = 0; i < n; i++) cnt[c[pn[i]]]++;
            for (int i = 1; i < classes; i++) cnt[i] += cnt[i-1];
            for (int i = n-1; i >= 0; i--) p[--cnt[c[pn[i]]]] = pn[i];
            cn[p[0]] = 0;
            classes = 1;
            for (int i = 1; i < n; i++) {
                pair<int, int> cur = {c[p[i]], c[(p[i] + (1 << h)) % n]};
                pair<int, int> prev = {c[p[i-1]], c[(p[i-1] + (1 << h)) % n]};
                if (cur != prev) classes++;
                cn[p[i]] = classes - 1;
            }
            c.swap(cn);
        }
        p.erase(p.begin());
        return p;
    }
    vector<int> cal_lcp(){
        vector<int> rank(n, 0);
        for (int i = 0; i < n; i++) rank.at(suffix_array[i]) = i;

        int k = 0;
        vector<int> lcp(n-1, 0);
        for (int i = 0; i < n; i++) {
            if (rank[i] == n - 1) {
                k = 0;
                continue;
            }
            int j = suffix_array[rank[i] + 1];
            while (i + k < n && j + k < n && s[i+k] == s[j+k]) k++;
            lcp[rank[i]] = k;
            if (k) k--;
        }
        return lcp; 
    }
    ll lower_bound(string sub){
        // Tìm lower_bound của sub trong mảng suffix các string. suffix_array[lower_bound(sub)] -> index của sub trong string
        // -1 nếu không tìm thấy
        ll left = 0, right = n-1;
        while (left < right) {
            ll mid = (left + right) /2;
            string _s = s.substr(suffix_array[mid], sub.size());
            if (sub <= _s) right = mid; // đoạn so sánh O(N) bị chậm
            else left = mid +1;
        }
        if (left < n && s.substr(suffix_array[left], sub.size()) < sub) left ++;
        if (s.substr(suffix_array[left], sub.size()) != sub) return -1;
        return left;
    }
    ll fast_lower_bound(string sub){
        subhash.load(sub);
        ll left = 0, right = n-1;
        while (left < right){
            ll mid = (left + right) /2;
            string _s = s.substr(suffix_array[mid], sub.size());
            // if (sub <= _s) right = mid; else left = mid+1; đoạn dưới dùng binary search để so sánh 2 string
            ll l = 0, r = min(sub.size(), _s.size());
            while (l < r -1){
                ll m = (l + r) /2;
                if (hash.substr(suffix_array[mid], suffix_array[mid] + m) != subhash.substr(0, m)){
                    r = m -1;
                } else l = m;
            }
            while (l < sub.size() && sub[l] == _s[l]) l++;
            if (l == sub.size() || sub[l] <= _s[l]) right = mid;
            else left = mid +1;
        }
        if (left < n && s.substr(suffix_array[left], sub.size()) < sub) left ++;
        if (s.substr(suffix_array[left], sub.size()) != sub) return -1;
        return left;
    }
    ll fast_upper_bound(string sub){
        subhash.load(sub);
        ll left = 0, right = n-1;
        while (left < right){
            ll mid = (left + right) /2;
            string _s = s.substr(suffix_array[mid], sub.size());
            ll l = 0, r = min(sub.size(), _s.size());
            while (l < r -1){
                ll m = (l + r) /2;
                if (hash.substr(suffix_array[mid], suffix_array[mid] + m) != subhash.substr(0, m)){
                    r = m -1;
                } else l = m;
            }
            while (l < sub.size() && sub[l] == _s[l]) l++;
            if (l == sub.size() || sub[l] >= _s[l]) left = mid+1;
            else right = mid;
        }
        if (left < n && s.substr(suffix_array[left], sub.size()) <= sub) left++;
        return left;
    }
    ll upper_bound(string sub) {
        // Tương tự lower_bound. Lưu ý lower_bound = upper_bound = n khi không tìm thấy sub
        ll left = 0, right = n-1;
        while (left < right){
            ll mid = (left + right) /2;
            if (s.substr(suffix_array[mid], sub.size()) <= sub){
                left = mid+1;
            } else right = mid;
        }
        if (left < n && s.substr(suffix_array[left], sub.size()) <= sub) left++;
        return left;
    }
    // đếm xem substring xuất hiện trong string bao nhiêu lần. Trong prefix đã sắp xếp tìm phần tử nhỏ nhất và lớn nhất bằng sub - https://codeforces.com/edu/course/2/lesson/2/3/practice/contest/269118/submission/168931121
    ll occurrence(string sub){
        this->subhash.load(sub);
        // ll low = lower_bound(sub);
        ll low = fast_lower_bound(sub);
        if (low == -1) return 0;
        ll up = fast_upper_bound(sub);
        return up - low;
    }
};

void solve(){
    string s1, s2;
    cin >> s1 >> s2;
    if (s1.size() > s2.size()) swap(s1, s2);
    int L; cin >> L;
    SuffixArray suf1(s1);
    SuffixArray suf2(s2);
    suf1.add_hash(g_hash);
    suf2.add_hash(g_hash);
    for (int i=1;i<=L;i++){
        ll ans = 0;
        for (int j=0;j<s1.size() - i+1;j++){
            string s = s1.substr(j, i);
            if (suf1.suffix_array[suf1.lower_bound(s)] == j) {
                ans += suf1.occurrence(s) * suf2.occurrence(s);
            }
            // dbg(ans);
        }
        cout << ans <<' ';
    }
    cout << '\n';
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    int n;
    cin >> n;
    g_hash.build();
    while (n--) solve();
    
    cerr << "Time : " << (double)clock() / (double)CLOCKS_PER_SEC << "s\n";
}
