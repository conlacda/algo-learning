inline std::string trim(std::string& str)
{
    while (str[str.size()-1] == ' ' || str[0] == ' '
        || str[str.size()-1] == '\n' || str[0] == '\n'){
        str.erase(str.find_last_not_of(' ')+1);         //suffixing spaces
        str.erase(0, str.find_first_not_of(' '));       //prefixing spaces
        str.erase(str.find_last_not_of('\n')+1);         //suffixing spaces
        str.erase(0, str.find_first_not_of('\n'));       //prefixing spaces
    }
    return str;
}

class Reader {
private:
    string errlog;
public:
    Reader() {
        // Build các file để run
        system("g++ -DDEBUG a.cpp -o mycode 2> err.log"); // build file để khi chạy nó trả log ra file err.log
        system("g++ -DDEBUG accepted.cpp -o accepted");
    }
    string input() {
        std::ifstream inp("inp.txt");
        std::string inpcnt((std::istreambuf_iterator<char>(inp)),std::istreambuf_iterator<char>());
        return inpcnt;
    }
    string myoutput() {
        system("mycode.exe");
        std::ifstream out("out.txt");
        std::string outcnt((std::istreambuf_iterator<char>(out)),std::istreambuf_iterator<char>());
        outcnt = trim(outcnt);
        return outcnt;
    }
    string correctoutput() {
        system("accepted.exe");
        std::ifstream out("accepted.out");
        // đọc kiểu này để có thể giữ nguyên được dấu space, \n trong file. chứ ko bị làm dẹp ra
        std::string outcnt((std::istreambuf_iterator<char>(out)),std::istreambuf_iterator<char>());
        outcnt = trim(outcnt);
        return outcnt;
    }

    bool checklog() {
        std::ifstream log("err.log");
        std::string logcnt((std::istreambuf_iterator<char>(log)),
                 std::istreambuf_iterator<char>());
        if ((ll) logcnt.find("warning") != -1 || (ll) logcnt.find("error") != -1 || (ll) logcnt.find("failed") != -1) {
            cout << "ERR ";
            cout << logcnt<<'\n';
            return false;
        }
        return true;
    }
    bool check(string type="onefile") {
        if (!checklog()) return false;
        if (myoutput().size() == 0) {
            cout << "Empty output. Maybe runtime error??\n";
            return false;
        }
        if (type == "onefile") return true; // tại đây nếu chỉ check 1 file thì chỉ cần xem nó có trả kết quả ra ko là được
        // TODO - thêm validate giá trị đầu ra vào đây nữa
        if (myoutput() != correctoutput()) {
            dbg(myoutput());
            dbg(correctoutput()); 
            cout << "Wrong answer. Rerun file with current input file\n";
            return false;
        }
        return true;
    }
};

Reader reader;