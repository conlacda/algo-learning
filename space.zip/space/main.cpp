// File này dùng để chạy validate
#include <bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

#include "debug.cpp"
#include "random.cpp" // sửa trong random.cpp
#include "reader.cpp" // reader.input | reader.myoutput | reader.correctoutput

int main() {
    ios::sync_with_stdio(0);
    std::cin.tie(0);
    for (int i = 0; i < 10; i++) {
        random.generate();
        if (!reader.check("twofile")) { // onefile || twofile
            return 0;
        }
    }
    cout << "It seems good, no problem!\n";
    cerr << "Time : " << (double)clock() / (double)CLOCKS_PER_SEC << "s\n";
    return 0;
}
/*
Kiểm tra file có bị lỗi gì ko
Thay đổi phần generate() tại random.cpp
Target file sẽ là a.cpp và accepted.cpp.
reader.check("twofile") - để check 2 file cùng output
reader.check("onefile") - kiểm tra xem file mình bị RE hay segmentfault ở testcase nào
*/