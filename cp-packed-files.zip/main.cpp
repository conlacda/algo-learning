#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#endif

void solve(){
    ll q; cin >> q;
    map<ll, ll> mapa, mapb;
    mapa[1] = 1;
    mapb[1] = 1;
    std::function<bool()> compare = [&](){
        string a ="", b ="";
        ll min_a = -1; ll max_a;
        for (ll i=1;i<27;i++){
            if (mapa[i] > 0){
                if (min_a == -1) min_a = i;
                max_a = i;
            }
        }
        ll max_b;
        for (ll i=27;i>=1;i--){
            if (mapb[i] > 0){
                max_b = i;
                break;
            }
        }
        dbg(min_a , max_b, mapa[min_a], mapb[max_b]);
        if (max_b > min_a) {
            return true;
        }
        // aabbb aaaaa -> trường hợp này phải có max_a == min_a và số kí tự nhỏ hơn
        if (max_a == max_b && mapa[min_a] < mapb[max_b]) return true;
        return false;
    };
    for (ll i=0;i<q;i++){
        ll t, num; string sub;
        cin >> t >> num; cin >> sub;
        if (t ==1) {
            for (auto v: sub) mapa[v-'a' + 1] += num;
        } else {
            for (auto v: sub) mapb[v-'a' + 1] += num;
        }
        if (compare()) {
            cout << "YES\n";
        } else cout << "NO\n";
    }
}
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    ll n;
    cin >> n;
    while (n--) solve();
    
    cerr << "Time : " << (double)clock() / (double)CLOCKS_PER_SEC << "s\n";
}
/*
a a
a aaa
aaa aaa
aaa aaaaaa
aaabb aaaaaa 
*/