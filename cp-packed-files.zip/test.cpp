#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#endif

class Random {
  public:
    Random(){
        srand (time(NULL));
    }

    ll Int(ll l, ll r){
        r++; if (l==r) return l;
        assert(l<r);
        return rand() %(r-l)+l; // assert(21<= r.randRange(21, 100) && r.randRange(21, 100) <= 100);
    }

    vector<ll> Arr(ll l, ll r, int num, bool unique = false){
        if (unique) assert(r-l+1 >= num);
        map<ll, bool> m;
        vector<ll> ans;
        for (int i=0;i<num;i++){
            ll k = this->Int(l, r);
            if (unique)
                while (m.find(k) != m.end())
                    k = this->Int(l, r);
            ans.push_back(this->Int(l, r));
        }
        return ans;
    }
    char Char(string str = "abcdefghijklmnopqrstuvwxyz"){
        ll idx = this->Int(0, str.size()-1);
        return str[idx];
    }
    string Str(int size){ // min_size
        string result = "";
        for (int i=0;i<size;i++){
            result += this->Char();
        }
        return result;
    }
    string Str(int min_size, int max_size){
        ll size = this->Int(min_size, max_size);
        return this->Str(size);
    }
    vector<vector<ll>> Graph(){
        // TODO
        vector<vector<ll>> result;
        return result;
    }
    vector<vector<ll>> Tree(){
        // TODO 
        // Phần này dùng DSU để chắc chắn nó không có cycle
        vector<vector<ll>> result;
        return result;
    }
    // TODO char, string, ...
};
/*
Random r;
r.Int(0, 10); [0, 10]
r.Arr(l, r, num, [unique]); // random 1 vector co chua num so tu [l, r] va co unique khong
r.Char(); // trả về 1 ký tự
r.Str(10); // trả về 1 string với size = 10
r.Str(2, 4); // trả về String có size từ 2->4
*/

inline std::string trim(std::string& str)
{
    while (str[str.size()-1] == ' ' || str[0] == ' '
        || str[str.size()-1] == '\n' || str[0] == '\n'){
        str.erase(str.find_last_not_of(' ')+1);         //suffixing spaces
        str.erase(0, str.find_first_not_of(' '));       //prefixing spaces
        str.erase(str.find_last_not_of('\n')+1);         //suffixing spaces
        str.erase(0, str.find_first_not_of('\n'));       //prefixing spaces
    }
    return str;
}
class Reader {
public:
    Reader() {}
    string read_input(){
        std::ifstream inp("inp.txt");
        std::string inpcnt((std::istreambuf_iterator<char>(inp)),std::istreambuf_iterator<char>());
        return inpcnt;
    }
    string read_myoutput(){
        system("main.exe");
        std::ifstream out("out.txt");
        std::string outcnt((std::istreambuf_iterator<char>(out)),std::istreambuf_iterator<char>());
        outcnt = trim(outcnt);
        return outcnt;
    }
    string read_correctoutput(){
        system("accepted.exe");
        std::ifstream out("accepted_out.txt");
        std::string outcnt((std::istreambuf_iterator<char>(out)),std::istreambuf_iterator<char>());
        outcnt = trim(outcnt);
        return outcnt;
    }
};
class Builder {
public:
    Builder(){
        system("g++ -DDEBUG accepted.cpp -o accepted 2> err.log");
        system("g++ -DDEBUG main.cpp -o main 2> err.log");
    }
};
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    Random r; Reader reader; Builder build;
    for (int i=0;i<10;i++){
        // Random dữ liệu
        ofstream out("inp.txt");
        out << r.Int(0, 1) <<'\n';
        out.close();
        // Chạy và so sánh các ouput
        string input = reader.read_input();
        string myoutput = reader.read_myoutput();

        /* Chạy file độc lập (khi có Runtime error) */
        // std::ifstream log("err.log");
        // std::string logcnt((std::istreambuf_iterator<char>(log)),
        //          std::istreambuf_iterator<char>());
        // if ((ll) logcnt.find("warning") != -1) {
        //     cout << "Problem occurs - check err.log";
        //     return 0;
        // }

        /* Chạy khi đi kèm với file đáp án*/
        string correct_output = reader.read_correctoutput();
        if (myoutput != correct_output){
            cout << "wrong answer. Check inp.txt\n";
            return 0;
        }
    }
    cout << "No problem found\n";
    return 0;
}