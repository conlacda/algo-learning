#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#define destructure(a) #a
#endif

class DSU {
 public:
  vector<int> parent, _rank;
  int N;
  DSU(int N) {
    this->N = N;
    this->parent.resize(N);
    this->_rank.resize(N);
    for (int i = 0; i < N; i++) {
      this->make_set(i);
    }
  }

  void make_set(int v) {
    this->parent[v] = v;
    this->_rank[v] = 0;
  }

  int find_set(int v) {
    assert(0 <= v && v < N);
    if (v == parent[v]) {
      return v;
    }
    return parent[v] = find_set(parent[v]);
  }

  void merge_set(int a, int b) {
    a = find_set(a);
    b = find_set(b);
    if (a != b) {
      if (_rank[a] < _rank[b]) {
        swap(a, b);
      }
      parent[b] = a;
      if (_rank[a] == _rank[b]) {
        _rank[a]++;
      }
    }
  }
};
struct Edge {
    ll u, v;
    double w;
    friend bool operator<(Edge a, Edge b){
        return a.w < b.w;
    }
    static bool lexicographic_order(Edge a, Edge b){
        if (a.u == b.u) return a.v < b.v;
            return a.u < b.u;    
    }
    friend std::ostream& operator<<(std::ostream& os, const Edge &s) { return os << destructure(s);}   
};
vector<Edge> kruskal(vector<vector<pair<ll,double>>> g){
    // Nhận vào 1 graph và trả về danh sách của MST
    int n = (int) g.size();
    vector<Edge> edges;
    for (int i=0;i<n;i++){
        for (auto pii: g[i]){
            edges.push_back(Edge{i, pii.first, pii.second});
        }
    }
    sort(edges.begin(), edges.end());
    DSU dsu(n);
    vector<Edge> mst;
    for (auto edge: edges){
        if (dsu.find_set(edge.u) != dsu.find_set(edge.v)){
            mst.push_back(edge);
            dsu.merge_set(edge.u, edge.v);
        }
    }
    if ((int)mst.size() != n-1){
        return {};
    }
    return mst;
}
/*
vector<vector<pair<ll, ll>>> g(n);
g[u].push_back({v, w});
vector<Edge> mst = kruskal(g);
mst.size() == 0 => ko có mst do đồ thị ko connected
*/

struct Point {
    int x, y;
    friend std::ostream& operator<<(std::ostream& os, const Point &s) { return os << destructure(s);}   
};
double distance(Point a, Point b) {
    return sqrt((a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y));
}
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    // cout << setprecision(2);
    int n;
    cin >> n;
    vector<Point> v;
    for (int i=0;i<n;i++) {
        int x, y;
        cin >> x >> y;
        v.push_back(Point{x, y});
    }
    dbg(v);
    vector<vector<pair<ll, double>>> adj(n);
    for (int i=0;i<n;i++) {
        for (int j=i+1;j<n;j++){
            adj[i].push_back({j, distance(v[i], v[j])});
            adj[j].push_back({i, distance(v[j], v[i])});
        }
    }
    vector<Edge> mst = kruskal(adj);
    double ans = 0;
    for (auto v: mst) ans += v.w;
    cout << setprecision(10) << ans;
    cerr << "Time : " << (double)clock() / (double)CLOCKS_PER_SEC << "s\n";
}