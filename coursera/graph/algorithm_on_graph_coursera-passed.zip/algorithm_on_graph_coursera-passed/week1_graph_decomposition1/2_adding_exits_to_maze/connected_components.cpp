#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#define destructure(a) #a
#endif

int number_of_components(vector<vector<int> > &adj) {
  int ans = 0;
  vector<bool> vis(adj.size());
  std::function<void(int)> dfs = [&](int u){
    vis[u] = true;
    for (auto v: adj[u]) {
        if (!vis[v]) {
            dfs(v);
        }
    }
  };
  for (int i=0;i<adj.size();i++){
    if (!vis[i]) {
        ans++;
        dfs(i);
    }
  }
  return ans;
}

int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif

      size_t n, m;
  std::cin >> n >> m;
  vector<vector<int> > adj(n, vector<int>());
  for (size_t i = 0; i < m; i++) {
    int x, y;
    std::cin >> x >> y;
    adj[x - 1].push_back(y - 1);
    adj[y - 1].push_back(x - 1);
  }
  std::cout << number_of_components(adj);
}
