#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double


#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#define destructure(a) #a
#endif

int reach(vector<vector<int>> &adj, int x, int y) {
    vector<bool> vis(adj.size());
    std::function<void(int)> dfs = [&](int u){
        vis[u] = true;
        for (auto v: adj[u]) {
            if (!vis[v]) {
                dfs(v);
            }
        }
    };
    dfs(x);
    if (vis[y]) return 1;
    return 0;
}

int main() {
    ios::sync_with_stdio(0); cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    size_t n, m;
    std::cin >> n >> m;
    vector<vector<int> > adj(n, vector<int>());
    for (size_t i = 0; i < m; i++) {
        int x, y;
        std::cin >> x >> y;
        adj[x - 1].push_back(y - 1);
        adj[y - 1].push_back(x - 1);
      }
    int x, y;
    std::cin >> x >> y;
    std::cout << reach(adj, x - 1, y - 1);
}