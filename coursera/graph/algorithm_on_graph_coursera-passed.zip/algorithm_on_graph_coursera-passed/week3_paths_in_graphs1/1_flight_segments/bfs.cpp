#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#define destructure(a) #a
#endif

// Verification:https://cses.fi/problemset/result/3379610/ - đã cập nhật mới
struct Node {
    int id; ll dist;
    friend bool operator<(const Node &a, const Node &b){
        return a.dist > b.dist;
    }
};
vector<ll> dijkstra(vector<vector<pair<int,int>>> G, int start){
    priority_queue<Node> Q;
    vector<bool> visited((int) G.size(), false);
    vector<ll> dist((int) G.size(), LLONG_MAX);
    dist.at(start) = 0; visited.at(start) = true;

    for (int i=0;i<G[start].size();i++){
        int u = G[start][i].first; ll start_to_u = G[start][i].second;
        if (dist[u] > start_to_u)
            dist[u] = start_to_u;
        visited[u] = true;
        Q.push({u, dist[u]});
    }

    while (!Q.empty()){
        ll d = Q.top().dist;
        int u = Q.top().id;
        Q.pop();
        if (d>dist[u]) continue;
        for (int i=0;i<G[u].size();i++){
            ll uv = G[u][i].second; int v = G[u][i].first;
            if (d+ uv <dist[v]){
                dist[v] = d + uv;
                Q.push({v, dist[v]});
            }
        }
    }
    // Nếu !hasEdge(start, i) thì dist[i] = -1
    for (int i=0;i<dist.size();i++){
        if (dist.at(i) == LLONG_MAX) dist.at(i) =-1;
    }
    return dist;
    /* Graph g(N); g.dijkstra(start);*/
}
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    int n, m;
    cin >> n >> m;
    vector<vector<pair<int,int>>> adj(n);
    for (int i=0;i<m;i++) {
        int u, v; cin >> u >> v; u--; v--;
        adj[u].push_back({v, 1});
        adj[v].push_back({u, 1});
    }
    int start, end;
    cin >> start>>end; start--; end--;
    vector<ll> dist = dijkstra(adj, start);
    cout << dist[end];
    // dbg(dist);
    
    cerr << "Time : " << (double)clock() / (double)CLOCKS_PER_SEC << "s\n";
}
