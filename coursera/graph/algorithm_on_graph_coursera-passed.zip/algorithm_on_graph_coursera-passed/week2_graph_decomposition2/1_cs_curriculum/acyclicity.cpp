#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

// Copy from nealwu's template - http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2016/p0200r0.html
template<class Fun> class y_combinator_result {
    Fun fun_;
public:
    template<class T> explicit y_combinator_result(T &&fun): fun_(std::forward<T>(fun)) {}
    template<class ...Args> decltype(auto) operator()(Args &&...args) { return fun_(std::ref(*this), std::forward<Args>(args)...); }
};
template<class Fun> decltype(auto) y_combinator(Fun &&fun) { return y_combinator_result<std::decay_t<Fun>>(std::forward<Fun>(fun)); }


template<typename A, typename B> ostream& operator<<(ostream &os, const pair<A, B> &p) { return os << '(' << p.first << ", " << p.second << ')'; }
template<typename T_container, typename T = typename enable_if<!is_same<T_container, string>::value, typename T_container::value_type>::type> ostream& operator<<(ostream &os, const T_container &v) { os << '{'; string sep; for (const T &x : v) os << sep << x, sep = ", "; return os << '}'; }

void dbg_out() { cerr << endl; }
template<typename Head, typename... Tail> void dbg_out(Head H, Tail... T) { cerr << ' ' << H; dbg_out(T...); }
#ifdef DEBUG
#define dbg(...) cerr << "(" << #__VA_ARGS__ << "):", dbg_out(__VA_ARGS__)
#else
#define dbg(...)
#endif

class Graph{
public:
    int V; // vertex num 0->V-1
    vector<vector<pair<int,int>>> G;
    vector<bool> visited;
    Graph(int V){
        this->V  = V;
        G.resize(this->V, {});
        visited.resize(this->V, false);
    }
    void addEdge(int u, int v, int w = -1){
        G.at(u).push_back({v, w});
    }
    void findSCC(){
        vector<vector<int>> sccs;
        // Tao ra reverseGraph
        auto reversedGraph = [&] () -> Graph {
            Graph rG = Graph(this->V);
            for (int i=0;i<G.size();i++){
                for (auto vw: G[i]){
                    int v = vw.first, w = vw.second;
                    rG.addEdge(v, i, w);
                }
            }
            return rG;
        };
        // Duyet DFS tren graph -> return topo 
        auto toposort = [&] (Graph rg) -> vector<int> {
            visited.assign(this->V, false);
            vector<int> post;
            auto explore = y_combinator([&] (auto explore, int u) -> void {
                if (!visited[u]) {
                    visited[u] = true;
                    for (int i=0;i<rg.G[u].size();i++){
                        int v = rg.G[u][i].first;
                        if (!visited[v]){
                            explore(v);
                        }
                    }
                    post.push_back(u);
                }
            });
            for (int i=0;i<rg.V;i++){
                explore(i);
            }
            reverse(post.begin(), post.end());
            return post;
        };
        vector<int> rpost = toposort(reversedGraph());
        // Tinh va dua ra scc
        auto dfs = [&] () -> void {
            visited.assign(this->V, false);
            vector<int> scc;
            auto explore = y_combinator([&] (auto explore, int u) -> void {
                if (!visited[u]) {
                    visited[u] = true;
                    for (auto vw: G[u]){
                        int v = vw.first;
                        if (!visited[v]){
                            explore(v);
                        }
                    }
                    scc.push_back(u);
                }
            });
            for (auto i: rpost){
                explore(i);
                if (scc.size()>0){
                    sccs.push_back(scc);
                    scc = {};
                }
            }
        };
        dfs();
        // Show
        if ((int) sccs.size() == this->V) {
            cout << 0;
        } else cout << 1;
    }
};

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    int n, m;
    cin >> n>> m;
    Graph g(n);
    for (int i=0;i<m;i++){
        int u, v;
        cin >> u>>v; u--; v--;
        g.addEdge(u, v);
    }
    g.findSCC();
}