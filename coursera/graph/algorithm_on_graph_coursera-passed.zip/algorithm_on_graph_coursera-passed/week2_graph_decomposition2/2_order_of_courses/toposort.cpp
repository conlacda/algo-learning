#include<bits/stdc++.h>

typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double

using namespace std;

#ifdef DEBUG
#include "debug.cpp"
#else
#define dbg(...)
#define destructure(a) #a
#endif

vector<int> toposort(vector<vector<int>> adj){
    vector<int> topo;
    vector<bool> visited(adj.size(), false);
    std::function<void(int)> topo_explore = [&](int start){
        if (!visited[start]) {
            visited[start] = true;
            for (auto p: adj[start]){
                int v = p;
                if (!visited[v]) topo_explore(v);
            }
            topo.push_back(start);
        }
    };
    for (int i=0;i<adj.size();i++) {
        topo_explore(i);
    }
    reverse(topo.begin(), topo.end()); // start 2 ... N
    return topo;
}

int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    size_t n, m;
    std::cin >> n >> m;
    vector<vector<int> > adj(n, vector<int>());
    for (size_t i = 0; i < m; i++) {
        int x, y;
        std::cin >> x >> y;
        adj[x - 1].push_back(y - 1);
    }
    vector<int> order = toposort(adj);
    for (size_t i = 0; i < order.size(); i++) {
        std::cout << order[i] + 1 << " ";
    }
}