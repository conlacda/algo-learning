#include<bits/stdc++.h>
 
typedef long long ll;
const ll mod = 1e9 + 7;
#define ld long double
 
using namespace std;
 
 
class Graph{ // graph chung cho tất cả
public:
    // General part
    int V; // vertex num 0->V-1
    vector<vector<pair<int,int>>> G;
    vector<bool> bmf_visited, visited;
    Graph(int V){
        this->V  = V +1;
        G.resize(this->V, {});
        bmf_visited.resize(this->V, false);
        visited.resize(this->V, false);
    }
    void addEdge(int u, int v, int w = -1){
        G.at(u).push_back({v, w});
    }
    // SCC function
    vector<vector<pair<int,int>>> reG; // reversed graph
    vector<int> post_re, post, buff;
    vector<bool> visited_re;
    vector<vector<int>> SCC;
    void generate_reG(){
        visited_re.resize(V, false);
        reG.resize(this->V, {});
        for (int u=0;u<V;u++){
            for (auto v: G[u]) { // u -> v.first= v.second
                reG[v.first].push_back({u, v.second});
            }
        }
    }
    void explore_re(int start){
        if (!visited_re[start]){
            visited_re[start] = true;
            for (auto v: reG[start]){
                if (!visited_re[v.first]) explore_re(v.first);
            }
            post_re.push_back(start);
        }
    }
    void dfs_re(){
        for (int i=0;i<V;i++) explore_re(i);
    }
    void explore(int start){
        if (!visited[start]){
            visited[start] = true;
            for (auto v: G[start]){
                if (!visited[v.first]) explore(v.first);
            }
            buff.push_back(start);
        }
    }
    void dfs(){
        reverse(post_re.begin(), post_re.end());
        post = post_re;
        for (auto v: post){
            if (!visited[v]) explore(v);
            if (buff.size()>0) SCC.push_back(buff);
            buff.clear();
        }
    }
    void findSCC(){
        generate_reG();
        dfs_re();
        dfs();
    }
    
    /*Thêm vào trong snippet `graph` + `scc` - bellmanford dùng kèm scc
    Tham khảo: https://www.youtube.com/watch?v=lyw4FaxrwHg
    Verification: https://cses.fi/problemset/result/2876164/
    g.findSCC();
    for (auto scc: g.SCC)
        g.BellmanFord(start, scc); # scc - danh sách các đỉnh. Nếu không thì để 1->N toàn bộ các đỉnh đồ thị
    hoặc vector<int> s; for (int i=0;i<g.V;i++) s.push_back(i); g.BellmanFord(1, s);
    */
    bool BellmanFord(int start, vector<int> scc){
        if (bmf_visited[start]) return false;
        // BellmanFord - tương tự như Dijkstra nhưng dành cho đồ thị có cạnh âm
        vector<int> trace(this->V, -1);
        vector<ll> dist(V, LLONG_MAX);
        dist[start] = 0;
        // for (int _=0; _<V;_++){
        for (int _=0;_<scc.size();_++){
            for (auto i: scc){ // for vertex: verticies
                if (bmf_visited[i] || dist[i] == LLONG_MAX) continue; // Optimization
                for (int j=0;j<G[i].size();j++){
                    int u = i, v = G[i][j].first; ll w = G[i][j].second;
                    if (dist[u] != LLONG_MAX && dist[u] + w < dist[v]) {
                        // tại đây dist[u] != LLONG_MAX là để chắc chắn đỉnh start có chạm tới được u
                        // Khi có start->u thì mọi khoảng cách từ u đi mới đc tính.
                        dist[v] = dist[u] + w;
                        trace[v] = u;
                    }
                }
            }
        }
        int start_of_cycle =-1;
        for (int _=0;_<scc.size();_++){
            for (auto i: scc){ // for vertex: verticies
                if (bmf_visited[i] || dist[i] == LLONG_MAX) continue;
                for (int j=0;j<G[i].size();j++){
                    int u = i, v = G[i][j].first; ll w = G[i][j].second;
                    if (dist[u] == -LLONG_MAX) dist[v] = -LLONG_MAX;
                    else if (dist[u] != LLONG_MAX && dist[u] + w < dist[v]) {
                        start_of_cycle = u; // circle thì mới optimize đc tiếp, đường thẳng thì nó sẵn các đoạn cố định
                        dist[v] = -LLONG_MAX;
                    }
                }
            }
        }
        // for (int i=1;i<V;i++){cout << "dist[" << i<<"] = " << dist[i] << '\n'; } // dist[u] - thể hiện khoảng cách từ start->u
        // for (auto v: trace) cout << v << ' ';
        // Find Cycle. Ignore if only want to get dist[] as dijsktra
        vector<bool> traced(this->V, false);
        vector<int> cycle; // store tracing verticies
        if (start_of_cycle == -1) return false;
        int x=start_of_cycle;
        cycle.push_back(x);
        while (true){
            traced[x] = true;
            x = trace[x];
            if (x==-1) return false; // trường hợp u->v và v->v <0. Nó tự quay quanh nó
            cycle.push_back(x);
            if (traced[x]) break;
        }
        reverse(cycle.begin(), cycle.end());
        cout << 1;
        return true;
    }
};
 
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    #ifdef DEBUG
        freopen("inp.txt", "r", stdin);
        freopen("out.txt", "w", stdout);
    #endif
    int N, V;
    cin >> N >> V;
    Graph g(N);
    for (int i=0;i<V;i++){
        int a, b, w;
        cin >> a >> b >> w;
        if (a == b && w<0) {
            cout << 1; return 0;
        }
        g.addEdge(a,b, w);
    }
    // vector<int>s;
    // for (int i=0;i<g.V;i++) s.push_back(i);
    // g.BellmanFord(1, s);
    g.findSCC();
    for (auto scc: g.SCC){
        if (g.BellmanFord(scc[0], scc)) return 0;
    }
    cout << 0;
    return 0;
}